<?php
require 'conexion.php'; // asegúrate que este archivo define $conn (PDO)

try {
    // Obtener todos los usuarios
    $sql = "SELECT id_usuario, contrasena FROM usuarios";
    $stmt = $conn->query($sql);
    $users = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($users as $u) {
        // Verifica si la contraseña NO está en formato SHA2 (64 caracteres hexadecimales)
        if (strlen($u['contrasena']) !== 64) {
            $hashed = hash('sha256', $u['contrasena']); // Encripta en formato SHA2-256

            // Actualiza solo ese usuario
            $update = $conn->prepare("UPDATE usuarios SET contrasena = :hashed WHERE id_usuario = :id");
            $update->execute([
                ':hashed' => $hashed,
                ':id' => $u['id_usuario']
            ]);

            echo "✅ Usuario con ID {$u['id_usuario']} actualizado correctamente.<br>";
        }
    }

    echo "<br>✅ Todos los usuarios revisados y actualizados.";
} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
