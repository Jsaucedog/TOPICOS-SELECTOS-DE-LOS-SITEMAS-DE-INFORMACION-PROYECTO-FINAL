<?php
$host = "localhost";
$db   = "ERP_cemex";
$user = "root";    // tu usuario MySQL
$pass = "Saucedojesg1_";        // tu contraseña MySQL

try {
    $conn = new PDO("mysql:host=$host;dbname=$db;charset=utf8", $user, $pass);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    echo "Conexión exitosa a la base de datos.";
} catch(PDOException $e) {
    die("Error de conexión: " . $e->getMessage());
}
?>
