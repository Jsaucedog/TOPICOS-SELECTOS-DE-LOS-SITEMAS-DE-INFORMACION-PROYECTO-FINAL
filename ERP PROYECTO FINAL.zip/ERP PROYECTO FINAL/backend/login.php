<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require __DIR__ . '/conexion.php';
header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = $_POST;
    $usuario = trim($data['username'] ?? '');
    $contraseña = trim($data['password'] ?? '');
    $remember = isset($data['remember']);

    if (empty($usuario) || empty($contraseña)) {
        http_response_code(400);
        echo json_encode(["status" => "error", "message" => "Por favor ingresa usuario y contraseña."]);
        exit;
    }

    try {
        $stmt = $conn->prepare("
        SELECT nombre_usuario, rol
        FROM usuarios
        WHERE nombre_usuario = :usuario
        AND contrasena = :password
        ");

        $stmt->bindParam(':usuario', $usuario);
        $stmt->bindParam(':password', $contraseña);
        $stmt->execute();

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user) {
            $_SESSION['usuario'] = $user['nombre_usuario'];
            $_SESSION['nombre'] = $user['nombre'] ?? '';
            $_SESSION['rol'] = $user['rol'] ?? '';

            if ($remember) {
                setcookie('usuario', $user['nombre_usuario'], time() + (86400 * 30), "/");
            }

            echo json_encode(["status" => "success", "message" => "Inicio de sesión exitoso."]);
        } else {
            http_response_code(401);
            echo json_encode(["status" => "error", "message" => "Usuario o contraseña incorrectos."]);
        }

    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(["status" => "error", "message" => "Error de base de datos: " . $e->getMessage()]);
    }

} else {
    http_response_code(405);
    echo json_encode(["status" => "error", "message" => "Método no permitido"]);
}
?>
