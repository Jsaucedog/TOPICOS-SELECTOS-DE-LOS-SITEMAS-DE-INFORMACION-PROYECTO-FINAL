<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require __DIR__ . '/conexion.php';
header('Content-Type: application/json; charset=utf-8');

$accion = $_GET['accion'] ?? $_GET['action'] ?? $_POST['accion'] ?? $_POST['action'] ?? '';

switch ($accion) {

    // -----------------------------
    // 1. LISTAR CLIENTES
    // -----------------------------
    case 'listar':
        $stmt = $conn->query("SELECT * FROM clientes ORDER BY id_cliente ASC");
        $clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['status' => 'ok', 'data' => $clientes], JSON_UNESCAPED_UNICODE);
        break;

    // -----------------------------
    // 2. AGREGAR CLIENTE
    // -----------------------------
    case 'agregar':
        if (!empty($_POST['nombre']) && !empty($_POST['apellido'])) {
            $sql = "INSERT INTO clientes (nombre, apellido, telefono, correo, direccion)
                    VALUES (:nombre, :apellido, :telefono, :correo, :direccion)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre'],
                ':apellido' => $_POST['apellido'],
                ':telefono' => $_POST['telefono'] ?? null,
                ':correo' => $_POST['correo'] ?? null,
                ':direccion' => $_POST['direccion'] ?? null
            ]);
            echo json_encode(['status' => 'ok', 'message' => 'Cliente agregado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Faltan datos obligatorios']);
        }
        break;

    // -----------------------------
    // 3. EDITAR CLIENTE
    // -----------------------------
    case 'editar':
        if (!empty($_POST['id_cliente'])) {
            $sql = "UPDATE clientes 
                    SET nombre = :nombre, apellido = :apellido, telefono = :telefono, 
                        correo = :correo, direccion = :direccion
                    WHERE id_cliente = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre'],
                ':apellido' => $_POST['apellido'],
                ':telefono' => $_POST['telefono'],
                ':correo' => $_POST['correo'],
                ':direccion' => $_POST['direccion'],
                ':id' => $_POST['id_cliente']
            ]);
            echo json_encode(['status' => 'ok', 'message' => 'Cliente actualizado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Falta el ID del cliente']);
        }
        break;

    // -----------------------------
    // 4. ELIMINAR CLIENTE
    // -----------------------------
    case 'eliminar':
        if (!empty($_POST['id_cliente'])) {
            $sql = "DELETE FROM clientes WHERE id_cliente = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $_POST['id_cliente']]);
            echo json_encode(['status' => 'ok', 'message' => 'Cliente eliminado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No se proporcionó ID para eliminar']);
        }
        break;

    // -----------------------------
    // 5. ACCIÓN NO VÁLIDA
    // -----------------------------
    default:
        echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
        break;
}
?>
