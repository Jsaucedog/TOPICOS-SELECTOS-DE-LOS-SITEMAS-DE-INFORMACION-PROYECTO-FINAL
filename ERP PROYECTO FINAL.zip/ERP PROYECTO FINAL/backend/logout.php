<?php
// /backend/logout.php

// 1. Iniciar la sesión
session_start();

// 2. Eliminar todas las variables de sesión
$_SESSION = array();

// 3. Destruir la sesión
session_destroy();

// 4. Redirigir a la página de LOGIN
// El usuario es enviado de vuelta a la página de inicio de sesión.
header("Location: ../fronted/Login.html"); 
exit;
?>