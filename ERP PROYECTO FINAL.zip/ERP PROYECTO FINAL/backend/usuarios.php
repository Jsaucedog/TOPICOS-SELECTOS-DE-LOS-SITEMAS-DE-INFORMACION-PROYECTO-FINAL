<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require __DIR__ . '/conexion.php';
header('Content-Type: application/json; charset=utf-8');

// Acción a realizar
$accion = $_GET['accion'] ?? $_GET['action'] ?? $_POST['accion'] ?? $_POST['action'] ?? '';

switch ($accion) {

    case 'listar':
        try {
            $stmt = $conn->query("SELECT * FROM usuarios");
            $usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($usuarios);
        } catch (PDOException $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'agregar':
        try {
            $sql = "INSERT INTO usuarios (nombre_usuario, contrasena, rol, id_empleado, estado)
                    VALUES (:nombre, :contrasena, :rol, :id_empleado, :estado)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre_usuario'],
                ':contrasena' => $_POST['contrasena'],
                ':rol' => $_POST['rol'],
                ':id_empleado' => !empty($_POST['id_empleado']) ? $_POST['id_empleado'] : null,
                ':estado' => $_POST['estado']
            ]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'editar':
        try {
            $sql = "UPDATE usuarios 
                    SET nombre_usuario=:nombre, contrasena=:contrasena, rol=:rol, 
                        id_empleado=:id_empleado, estado=:estado
                    WHERE id_usuario=:id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre_usuario'],
                ':contrasena' => $_POST['contrasena'],
                ':rol' => $_POST['rol'],
                ':id_empleado' => !empty($_POST['id_empleado']) ? $_POST['id_empleado'] : null,
                ':estado' => $_POST['estado'],
                ':id' => $_POST['id_usuario']
            ]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    case 'eliminar':
        try {
            $sql = "DELETE FROM usuarios WHERE id_usuario=:id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $_POST['id_usuario']]);
            echo json_encode(['success' => true]);
        } catch (PDOException $e) {
            echo json_encode(['error' => $e->getMessage()]);
        }
        break;

    default:
        echo json_encode(['error' => 'Acción no válida']);
        break;
}
?>
