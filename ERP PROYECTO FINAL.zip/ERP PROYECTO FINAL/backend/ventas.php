<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');
require __DIR__ . '/conexion.php';

$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';

try {
    switch ($accion) {

        // ===============================
        // LISTAR EMPLEADOS
        // ===============================
        case 'listar_empleados':
            $stmt = $conn->prepare("SELECT id_empleado, nombre, apellido 
                                    FROM empleados 
                                    WHERE LOWER(departamento) = 'ventas'
                                    ORDER BY nombre");
            $stmt->execute();
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ===============================
        // LISTAR CLIENTES
        // ===============================
        case 'listar_clientes':
            $stmt = $conn->query("SELECT id_cliente, nombre, apellido FROM clientes");
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ===============================
        // LISTAR PRODUCTOS
        // ===============================
        case 'listar_productos':
            $stmt = $conn->query("SELECT id_producto, nombre, precio FROM productos");
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ===============================
        // REGISTRAR VENTA + DETALLE
        // ===============================
        case 'registrar':
            $id_cliente = $_POST['id_cliente'] ?? null;
            $id_empleado = $_POST['id_empleado'] ?? null;
            $total = $_POST['total'] ?? 0;
            $detalle = json_decode($_POST['detalle'] ?? '[]', true);

            if (!$id_cliente || !$id_empleado || empty($detalle)) {
                throw new Exception('Faltan datos para registrar la venta.');
            }

            // Iniciar transacción
            $conn->beginTransaction();

            // Insertar en la tabla VENTAS
            $stmt = $conn->prepare("INSERT INTO ventas (id_cliente, id_empleado, fecha, total)
                                    VALUES (:id_cliente, :id_empleado, NOW(), :total)");
            $stmt->execute([
                ':id_cliente' => $id_cliente,
                ':id_empleado' => $id_empleado,
                ':total' => $total
            ]);

            $id_venta = $conn->lastInsertId();

            // Insertar en DETALLE_VENTAS
            $stmt_det = $conn->prepare("INSERT INTO detalle_ventas (id_venta, id_producto, cantidad, subtotal)
                                        VALUES (:id_venta, :id_producto, :cantidad, :subtotal)");

            foreach ($detalle as $item) {
                $stmt_det->execute([
                    ':id_venta' => $id_venta,
                    ':id_producto' => $item['id_producto'],
                    ':cantidad' => $item['cantidad'],
                    ':subtotal' => $item['subtotal']
                ]);
            }

            $conn->commit();

            echo json_encode(['exito' => true, 'mensaje' => 'Venta registrada correctamente.']);
            break;

        // ===============================
        // LISTAR HISTORIAL
        // ===============================
        case 'listar':
            $sql = "SELECT v.id_venta, 
                           CONCAT(c.nombre, ' ', c.apellido) AS cliente, 
                           CONCAT(e.nombre, ' ', e.apellido) AS empleado, 
                           v.fecha, v.total
                    FROM ventas v
                    JOIN clientes c ON v.id_cliente = c.id_cliente
                    JOIN empleados e ON v.id_empleado = e.id_empleado
                    ORDER BY v.id_venta DESC";
            $stmt = $conn->query($sql);
            echo json_encode(['status' => 'ok', 'data' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
            break;

        // ===============================
        // NUEVO: ESTADÍSTICAS
        // ===============================
    case 'estadisticas':
        // === Total de ventas de los últimos 3 meses ===
        $stmt = $conn->query("
            SELECT 
                DATE_FORMAT(fecha, '%Y-%m') AS mes, 
                SUM(total) AS total_mes
            FROM ventas
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY DATE_FORMAT(fecha, '%Y-%m')
            ORDER BY mes DESC
        ");
        $ventas_meses = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // === Top 3 productos más vendidos (por cantidad) ===
        $stmt = $conn->query("
            SELECT p.nombre, SUM(dv.cantidad) AS total_vendido
            FROM detalle_ventas dv
            JOIN productos p ON dv.id_producto = p.id_producto
            JOIN ventas v ON dv.id_venta = v.id_venta
            WHERE v.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY dv.id_producto
            ORDER BY total_vendido DESC
            LIMIT 3
        ");
        $top_productos = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // === Top 3 empleados con mayores ventas ===
        $stmt = $conn->query("
            SELECT e.nombre, e.apellido, SUM(v.total) AS total_ventas
            FROM ventas v
            JOIN empleados e ON v.id_empleado = e.id_empleado
            WHERE v.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY v.id_empleado
            ORDER BY total_ventas DESC
            LIMIT 3
        ");
        $top_empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'status' => 'ok',
            'data' => [
                'ventas_meses' => $ventas_meses,
                'top_productos' => $top_productos,
                'top_empleados' => $top_empleados
            ]
        ]);
        break;
    }

} catch (Exception $e) {
    if ($conn->inTransaction()) $conn->rollBack();
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}
