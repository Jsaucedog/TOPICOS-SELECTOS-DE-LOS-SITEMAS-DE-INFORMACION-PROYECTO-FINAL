<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require __DIR__ . '/conexion.php';
header('Content-Type: application/json; charset=utf-8');

// Acción a realizar
$accion = $_GET['accion'] ?? $_GET['action'] ?? $_POST['accion'] ?? $_POST['action'] ?? '';

switch ($accion) {

    // -----------------------------
    // 1. LISTAR EMPLEADOS
    // -----------------------------
    case 'listar':
        $stmt = $conn->query("SELECT * FROM empleados ORDER BY id_empleado ASC");
        $empleados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode(['status' => 'ok', 'data' => $empleados], JSON_UNESCAPED_UNICODE);
        break;

    // -----------------------------
    // 2. AGREGAR EMPLEADO
    // -----------------------------
    case 'agregar':
        if (
            !empty($_POST['nombre']) &&
            !empty($_POST['apellido']) &&
            !empty($_POST['fecha_contratacion'])
        ) {
            $sql = "INSERT INTO empleados (nombre, apellido, puesto, departamento, salario, fecha_contratacion)
                    VALUES (:nombre, :apellido, :puesto, :departamento, :salario, :fecha_contratacion)";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre'],
                ':apellido' => $_POST['apellido'],
                ':puesto' => $_POST['puesto'] ?? null,
                ':departamento' => $_POST['departamento'] ?? null,
                ':salario' => $_POST['salario'] ?? 0,
                ':fecha_contratacion' => $_POST['fecha_contratacion']
            ]);
            echo json_encode(['status' => 'ok', 'message' => 'Empleado agregado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Faltan datos obligatorios']);
        }
        break;

    // -----------------------------
    // 3. ACTUALIZAR EMPLEADO
    // -----------------------------
    case 'editar':
        if (!empty($_POST['id_empleado'])) {
            $sql = "UPDATE empleados SET nombre = :nombre, apellido = :apellido, puesto = :puesto, 
                    departamento = :departamento, salario = :salario, fecha_contratacion = :fecha_contratacion
                    WHERE id_empleado = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([
                ':nombre' => $_POST['nombre'],
                ':apellido' => $_POST['apellido'],
                ':puesto' => $_POST['puesto'],
                ':departamento' => $_POST['departamento'],
                ':salario' => $_POST['salario'],
                ':fecha_contratacion' => $_POST['fecha_contratacion'],
                ':id' => $_POST['id_empleado']
            ]);
            echo json_encode(['status' => 'ok', 'message' => 'Empleado actualizado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Falta el ID del empleado']);
        }
        break;

    // -----------------------------
    // 4. ELIMINAR EMPLEADO
    // -----------------------------
    case 'eliminar':
        if (!empty($_POST['id_empleado'])) {
            $sql = "DELETE FROM empleados WHERE id_empleado = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $_POST['id_empleado']]);
            echo json_encode(['status' => 'ok', 'message' => 'Empleado eliminado correctamente']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'No se proporcionó ID para eliminar']);
        }
        break;

    // -----------------------------
    // 5. ACCIÓN NO VÁLIDA
    // -----------------------------
    default:
        echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
        break;
}
?>
