<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require 'conexion.php';

$accion = $_GET["accion"] ?? $_POST["accion"] ?? "";

function responder($ok, $msg, $data = [])
{
    echo json_encode(["ok" => $ok, "message" => $msg, "data" => $data]);
    exit;
}

try {

    /* ============================================================
        1. LISTAR EMPLEADOS DE PRODUCCIÓN
    ============================================================ */
    if ($accion === "empleados") {

        $sql = "SELECT id_empleado, nombre, apellido 
                FROM empleados 
                WHERE departamento = 'Produccion'";
        $stmt = $conn->query($sql);

        responder(true, "OK", $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /* ============================================================
        2. LISTAR PRODUCTOS
    ============================================================ */
    if ($accion === "productos") {

        $sql = "SELECT * FROM productos";
        $stmt = $conn->query($sql);

        responder(true, "OK", $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /* ============================================================
        3. AGREGAR PRODUCTO
    ============================================================ */
    if ($accion === "producto_agregar") {

        $sql = "INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $_POST["nombre"],
            $_POST["precio"],
            $_POST["stock"]
        ]);

        responder(true, "Producto agregado correctamente");
    }

    /* ============================================================
        4. ELIMINAR PRODUCTO
    ============================================================ */
    if ($accion === "producto_eliminar") {

        $sql = "DELETE FROM productos WHERE id_producto = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$_POST["id_producto"]]);

        responder(true, "Producto eliminado");
    }

    /* ============================================================
        5. REGISTRAR PRODUCCIÓN
    ============================================================ */
    if ($accion === "agregar") {

        $sql = "INSERT INTO produccion (id_empleado, id_producto, cantidad, estado, fecha)
                VALUES (?, ?, ?, ?, NOW())";

        $stmt = $conn->prepare($sql);
        $stmt->execute([
            $_POST["id_empleado"],
            $_POST["id_producto"],
            $_POST["cantidad"],
            $_POST["estado"]
        ]);

        responder(true, "Producción registrada");
    }

    /* ============================================================
        6. LISTAR PRODUCCIÓN
    ============================================================ */
    if ($accion === "listar") {

        $sql = "SELECT p.id_produccion,
                       e.nombre AS emp_nom,
                       e.apellido AS emp_ape,
                       pr.nombre AS prod_nom,
                       p.cantidad,
                       p.estado,
                       p.fecha
                FROM produccion p
                INNER JOIN empleados e ON p.id_empleado = e.id_empleado
                INNER JOIN productos pr ON p.id_producto = pr.id_producto
                ORDER BY p.fecha DESC";

        $stmt = $conn->query($sql);

        responder(true, "OK", $stmt->fetchAll(PDO::FETCH_ASSOC));
    }

    /* ============================================================
        7. ELIMINAR REGISTRO DE PRODUCCIÓN
    ============================================================ */
    if ($accion === "eliminar") {

        $sql = "DELETE FROM produccion WHERE id_produccion = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$_POST["id_produccion"]]);

        responder(true, "Registro eliminado");
    }

    // Acción no encontrada
    responder(false, "Acción no válida: $accion");

} catch (Exception $e) {

    responder(false, "Error en servidor: " . $e->getMessage());
}
