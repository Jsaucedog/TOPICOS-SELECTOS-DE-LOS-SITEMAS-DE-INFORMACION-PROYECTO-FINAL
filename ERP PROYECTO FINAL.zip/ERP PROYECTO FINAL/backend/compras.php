<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json; charset=utf-8');
session_start();

// Ajusta la ruta si tu conexion.php está en otra ubicación
require __DIR__ . '/conexion.php'; // debe definir $conn (PDO)

$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';

try {
    switch ($accion) {

        /* =======================================================
         * LISTAR COMPRAS (resumen)
         * ======================================================= */
        case 'listar':
            $sql = "SELECT c.id_compra, c.fecha, c.total, 
                           p.id_proveedor, p.nombre AS proveedor,
                           e.id_empleado, CONCAT(e.nombre, ' ', e.apellido) AS empleado
                    FROM compras c
                    LEFT JOIN proveedores p ON c.id_proveedor = p.id_proveedor
                    LEFT JOIN empleados e ON c.id_empleado = e.id_empleado
                    ORDER BY c.id_compra DESC";
            $stmt = $conn->query($sql);
            $compras = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $compras], JSON_UNESCAPED_UNICODE);
            break;

        /* =======================================================
         * LISTAR DETALLES DE UNA COMPRA
         * ======================================================= */
        case 'detalles':
            $id = $_GET['id'] ?? $_POST['id_compra'] ?? null;
            if (!$id) {
                echo json_encode(['status' => 'error', 'message' => 'ID compra no proporcionado']);
                exit;
            }

            $sql = "SELECT dc.id_detalle, dc.id_compra, dc.id_producto, 
                           pr.nombre AS producto, dc.cantidad, dc.subtotal
                    FROM detalle_compras dc
                    LEFT JOIN productos pr ON dc.id_producto = pr.id_producto
                    WHERE dc.id_compra = :id";
            $stmt = $conn->prepare($sql);
            $stmt->execute([':id' => $id]);
            $detalles = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $detalles], JSON_UNESCAPED_UNICODE);
            break;

        /* =======================================================
         * LISTAR PROVEEDORES, PRODUCTOS Y EMPLEADOS (para selects)
         * ======================================================= */
        case 'listar_proveedores':
            $stmt = $conn->query("SELECT id_proveedor, nombre FROM proveedores ORDER BY nombre");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $rows], JSON_UNESCAPED_UNICODE);
            break;

        case 'listar_productos':
            $stmt = $conn->query("SELECT id_producto, nombre, precio, stock FROM productos ORDER BY nombre");
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $rows], JSON_UNESCAPED_UNICODE);
            break;

        case 'listar_empleados':
            // Solo mostrar empleados que pertenecen al departamento de COMPRAS
            $stmt = $conn->prepare("SELECT id_empleado, nombre, apellido 
                                    FROM empleados 
                                    WHERE LOWER(departamento) = 'compras'
                                    ORDER BY nombre");
            $stmt->execute();
            $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode(['status' => 'ok', 'data' => $rows], JSON_UNESCAPED_UNICODE);
            break;

        /* =======================================================
         * AGREGAR COMPRA CON DETALLES
         * Espera: id_proveedor, id_empleado, detalles (JSON)
         * ======================================================= */
        case 'agregar':
            $id_proveedor = $_POST['id_proveedor'] ?? null;
            $id_empleado  = $_POST['id_empleado'] ?? null;
            $detalles_json = $_POST['detalles'] ?? '[]';

            $detalles = json_decode($detalles_json, true);
            if (!is_array($detalles) || count($detalles) === 0) {
                echo json_encode(['status' => 'error', 'message' => 'Detalles de compra vacíos']);
                exit;
            }

            $conn->beginTransaction();

            try {
                $total = 0.0;
                $lineas = [];
                $stmtProd = $conn->prepare("SELECT nombre, precio, stock FROM productos WHERE id_producto = :id");

                foreach ($detalles as $line) {
                    $id_producto = (int)($line['id_producto'] ?? 0);
                    $cantidad = (int)($line['cantidad'] ?? 0);
                    if ($id_producto <= 0 || $cantidad <= 0) {
                        throw new Exception("Producto o cantidad inválida en detalles");
                    }

                    $stmtProd->execute([':id' => $id_producto]);
                    $prod = $stmtProd->fetch(PDO::FETCH_ASSOC);
                    if (!$prod) throw new Exception("Producto ID {$id_producto} no encontrado");

                    $precio = (float)$prod['precio'];
                    $subtotal = round($precio * $cantidad, 2);
                    $total += $subtotal;

                    $lineas[] = [
                        'id_producto' => $id_producto,
                        'cantidad' => $cantidad,
                        'precio' => $precio,
                        'subtotal' => $subtotal
                    ];
                }

                // Insertar compra
                $sql = "INSERT INTO compras (id_proveedor, id_empleado, total)
                        VALUES (:prov, :emp, :total)";
                $stmt = $conn->prepare($sql);
                $stmt->execute([
                    ':prov'  => $id_proveedor ?: null,
                    ':emp'   => $id_empleado ?: null,
                    ':total' => $total
                ]);
                $id_compra = $conn->lastInsertId();

                // Insertar detalles
                $stmtDet = $conn->prepare("
                    INSERT INTO detalle_compras (id_compra, id_producto, cantidad, subtotal)
                    VALUES (:compra, :producto, :cantidad, :subtotal)
                ");
                foreach ($lineas as $l) {
                    $stmtDet->execute([
                        ':compra'   => $id_compra,
                        ':producto' => $l['id_producto'],
                        ':cantidad' => $l['cantidad'],
                        ':subtotal' => $l['subtotal']
                    ]);

                    // Si deseas actualizar stock:
                    // $conn->prepare("UPDATE productos SET stock = stock + :c WHERE id_producto = :id")
                    //      ->execute([':c'=>$l['cantidad'], ':id'=>$l['id_producto']]);
                }

                $conn->commit();
                echo json_encode([
                    'status' => 'ok',
                    'message' => 'Compra registrada',
                    'id_compra' => $id_compra,
                    'total' => $total
                ], JSON_UNESCAPED_UNICODE);

            } catch (Exception $e) {
                $conn->rollBack();
                echo json_encode(['status' => 'error', 'message' => 'Error al registrar compra: ' . $e->getMessage()], JSON_UNESCAPED_UNICODE);
            }
            break;

        /* =======================================================
         * ELIMINAR COMPRA Y DETALLES
         * ======================================================= */
        case 'eliminar':
            $id = $_POST['id_compra'] ?? null;
            if (!$id) {
                echo json_encode(['status' => 'error', 'message' => 'ID de compra no proporcionado']);
                exit;
            }

            $conn->beginTransaction();
            try {
                $stmt = $conn->prepare("DELETE FROM detalle_compras WHERE id_compra = :id");
                $stmt->execute([':id' => $id]);

                $stmt = $conn->prepare("DELETE FROM compras WHERE id_compra = :id");
                $stmt->execute([':id' => $id]);

                $conn->commit();
                echo json_encode(['status' => 'ok', 'message' => 'Compra eliminada']);
            } catch (Exception $e) {
                $conn->rollBack();
                echo json_encode(['status' => 'error', 'message' => 'Error al eliminar: ' . $e->getMessage()]);
            }
            break;

        /* =======================================================
         * AGREGAR PROVEEDOR
         * ======================================================= */
        case 'agregar_proveedor':
            $nombre = $_POST['nombre'] ?? '';
            $correo = $_POST['correo'] ?? null;
            $telefono = $_POST['telefono'] ?? null;

            if (!$nombre) {
                echo json_encode(['status' => 'error', 'message' => 'Falta el nombre del proveedor']);
                break;
            }

            $stmt = $conn->prepare("
                INSERT INTO proveedores (nombre, correo, telefono)
                VALUES (:nombre, :correo, :telefono)
            ");
            $stmt->execute([
                ':nombre' => $nombre,
                ':correo' => $correo,
                ':telefono' => $telefono
            ]);

            echo json_encode(['status' => 'ok', 'message' => 'Proveedor agregado']);
            break;

        /* =======================================================
         * ACCIÓN NO VÁLIDA
         * ======================================================= */
        default:
            echo json_encode(['status' => 'error', 'message' => 'Acción no válida']);
            break;
    }

} catch (PDOException $ex) {
    echo json_encode(['status' => 'error', 'message' => 'Error de BD: ' . $ex->getMessage()]);
}
