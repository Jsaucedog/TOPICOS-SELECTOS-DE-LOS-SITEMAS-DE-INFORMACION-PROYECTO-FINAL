<?php
// backend/finanzas.php
header('Content-Type: application/json; charset=utf-8');
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/conexion.php';

$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';

try {
    // ------------------------------------------------
    // AGREGAR MOVIMIENTO (ingreso / egreso)
    // ------------------------------------------------
    if ($accion === 'agregar') {
        $tipo  = $_POST['tipo'] ?? '';
        $monto = floatval($_POST['monto'] ?? 0);

        if (!in_array($tipo, ['ingreso', 'egreso']) || $monto <= 0) {
            http_response_code(400);
            echo json_encode(['error' => 'Datos inválidos (tipo o monto).']);
            exit;
        }

        $stmt = $conn->prepare("INSERT INTO movimientos (tipo, monto, fecha) VALUES (:tipo, :monto, NOW())");
        $stmt->execute([':tipo' => $tipo, ':monto' => $monto]);

        echo json_encode(['ok' => true, 'message' => 'Movimiento agregado correctamente']);
        exit;
    }

    // ------------------------------------------------
    // LISTAR MOVIMIENTOS (unificado)
    // Devuelve filas combinadas: movimientos manuales, ventas, compras, nómina (estimada)
    // ------------------------------------------------
    if ($accion === 'listar') {
        // 1) Movimientos manuales
        $stmt1 = $conn->prepare("SELECT id_movimiento AS id, tipo, monto, fecha, id_venta, id_compra, 'movimiento' AS origen FROM movimientos");

        // 2) Ventas (tomamos el total desde tabla ventas)
        $stmt2 = $conn->prepare("SELECT id_venta AS id, 'venta' AS tipo, total AS monto, fecha, id_venta, NULL AS id_compra, 'venta' AS origen FROM ventas");

        // 3) Compras
        $stmt3 = $conn->prepare("SELECT id_compra AS id, 'compra' AS tipo, total AS monto, fecha, NULL AS id_venta, id_compra, 'compra' AS origen FROM compras");

        // Ejecutar y combinar
        $stmt1->execute();
        $movs_manual = $stmt1->fetchAll(PDO::FETCH_ASSOC);

        $stmt2->execute();
        $ventas = $stmt2->fetchAll(PDO::FETCH_ASSOC);

        $stmt3->execute();
        $compras = $stmt3->fetchAll(PDO::FETCH_ASSOC);

        // 4) Nómina estimada: generamos una fila única con la suma de salarios (para referencia)
        $stmtNom = $conn->prepare("SELECT IFNULL(SUM(salario),0) AS total_nomina FROM empleados");
        $stmtNom->execute();
        $nomina_sum = (float) $stmtNom->fetch(PDO::FETCH_ASSOC)['total_nomina'];
        $nominaRow = [];
        if ($nomina_sum > 0) {
            $nominaRow = [[
                'id' => null,
                'tipo' => 'nomina',
                'monto' => $nomina_sum,
                'fecha' => date('Y-m-d'),
                'id_venta' => null,
                'id_compra' => null,
                'origen' => 'nomina'
            ]];
        }

        // Combinar todas las filas y ordenar por fecha desc
        $combined = array_merge($movs_manual, $ventas, $compras, $nominaRow);

        // Normalizar fechas y ordenar
        usort($combined, function ($a, $b) {
            $fa = strtotime($a['fecha'] ?? '1970-01-01');
            $fb = strtotime($b['fecha'] ?? '1970-01-01');
            return $fb <=> $fa;
        });

        echo json_encode($combined, JSON_UNESCAPED_UNICODE);
        exit;
    }

    // ------------------------------------------------
    // ESTADÍSTICAS: últimos 3 meses (ingresos / egresos / ventas / compras / nómina)
    // ------------------------------------------------
    if ($accion === 'estadisticas') {
        // Generar array de últimos 3 meses (orden cronológico asc)
        $meses = [];
        for ($i = 2; $i >= 0; $i--) {
            $dt = new DateTime("first day of -{$i} month");
            $key = $dt->format('Y-m'); // "2025-11"
            $label = $dt->format('M'); // "Nov"
            $meses[$key] = [
                'year' => (int)$dt->format('Y'),
                'month' => (int)$dt->format('m'),
                'mes_label' => $label,
                'ingresos' => 0.0,
                'egresos' => 0.0,
                'ventas' => 0.0,
                'compras' => 0.0,
                'nomina' => 0.0,
                'movimientos' => 0.0
            ];
        }

        // 1) Ventas por mes
        $stmtV = $conn->prepare("
            SELECT YEAR(fecha) AS y, MONTH(fecha) AS m, IFNULL(SUM(total),0) AS total_ventas
            FROM ventas
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY YEAR(fecha), MONTH(fecha)
        ");
        $stmtV->execute();
        foreach ($stmtV->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $key = sprintf('%04d-%02d', $r['y'], $r['m']);
            if (isset($meses[$key])) {
                $meses[$key]['ventas'] = (float)$r['total_ventas'];
                $meses[$key]['ingresos'] += (float)$r['total_ventas'];
            }
        }

        // 2) Compras por month
        $stmtC = $conn->prepare("
            SELECT YEAR(fecha) AS y, MONTH(fecha) AS m, IFNULL(SUM(total),0) AS total_compras
            FROM compras
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY YEAR(fecha), MONTH(fecha)
        ");
        $stmtC->execute();
        foreach ($stmtC->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $key = sprintf('%04d-%02d', $r['y'], $r['m']);
            if (isset($meses[$key])) {
                $meses[$key]['compras'] = (float)$r['total_compras'];
                $meses[$key]['egresos'] += (float)$r['total_compras'];
            }
        }

        // 3) Movimientos manuales (ingresos/egresos)
        $stmtM = $conn->prepare("
            SELECT YEAR(fecha) AS y, MONTH(fecha) AS m, tipo, IFNULL(SUM(monto),0) AS total_mov
            FROM movimientos
            WHERE fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY YEAR(fecha), MONTH(fecha), tipo
        ");
        $stmtM->execute();
        foreach ($stmtM->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $key = sprintf('%04d-%02d', $r['y'], $r['m']);
            if (!isset($meses[$key])) continue;
            $tot = (float)$r['total_mov'];
            $meses[$key]['movimientos'] += $tot;
            if (in_array($r['tipo'], ['venta','ingreso'])) {
                $meses[$key]['ingresos'] += $tot;
            } else { // egreso, compra (should be 'egreso')
                $meses[$key]['egresos'] += $tot;
            }
        }

        // 4) Nómina: asumimos pago mensual = suma de salarios; se aplica en cada mes
        $stmtNom = $conn->prepare("SELECT IFNULL(SUM(salario),0) AS total_nomina FROM empleados");
        $stmtNom->execute();
        $nomina_total = (float)$stmtNom->fetch(PDO::FETCH_ASSOC)['total_nomina'];
        // Aplicar nómina a cada mes
        foreach ($meses as $k => &$m) {
            $m['nomina'] = $nomina_total;
            $m['egresos'] += $nomina_total;
        }
        unset($m);

        // Convertir a array ordenado por fecha asc
        $outMeses = [];
        foreach ($meses as $k => $m) {
            $outMeses[] = [
                'mes' => $m['mes_label'],
                'year_month' => $k,
                'ingresos' => round($m['ingresos'], 2),
                'egresos' => round($m['egresos'], 2),
                'ventas' => round($m['ventas'], 2),
                'compras' => round($m['compras'], 2),
                'nomina' => round($m['nomina'], 2),
                'movimientos' => round($m['movimientos'], 2)
            ];
        }

        // 5) Top 3 productos (últimos 3 meses) - usa detalle_ventas
        $stmtTopP = $conn->prepare("
            SELECT p.nombre, IFNULL(SUM(dv.cantidad),0) AS total_vendido
            FROM detalle_ventas dv
            JOIN ventas v ON dv.id_venta = v.id_venta
            JOIN productos p ON dv.id_producto = p.id_producto
            WHERE v.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY p.id_producto
            ORDER BY total_vendido DESC
            LIMIT 3
        ");
        $stmtTopP->execute();
        $topProductos = $stmtTopP->fetchAll(PDO::FETCH_ASSOC);

        // 6) Top 3 empleados por ventas (total) en últimos 3 meses
        $stmtTopE = $conn->prepare("
            SELECT e.id_empleado, CONCAT(e.nombre, ' ', e.apellido) AS nombre, IFNULL(SUM(v.total),0) AS total_vendido
            FROM ventas v
            JOIN empleados e ON v.id_empleado = e.id_empleado
            WHERE v.fecha >= DATE_SUB(CURDATE(), INTERVAL 3 MONTH)
            GROUP BY e.id_empleado
            ORDER BY total_vendido DESC
            LIMIT 3
        ");
        $stmtTopE->execute();
        $topEmpleados = $stmtTopE->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode([
            'meses' => $outMeses,
            'top_productos' => $topProductos,
            'top_empleados' => $topEmpleados
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }

    echo json_encode(['error' => 'Acción inválida']);
    exit;

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
    exit;
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
    exit;
}
