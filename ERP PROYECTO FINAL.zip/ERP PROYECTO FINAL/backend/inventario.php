<?php
require __DIR__ . '/conexion.php';
header('Content-Type: application/json; charset=utf-8');

$accion = $_GET['accion'] ?? $_POST['accion'] ?? '';

try {

    /* =======================================================
       ACCIÓN: LISTAR INVENTARIO (paginación + búsqueda)
    ======================================================= */
    if ($accion === 'listar') {

        $pagina = max(1, intval($_GET['pagina'] ?? 1));
        $busqueda = $_GET['busqueda'] ?? '';
        $filasPorPagina = 10;
        $offset = ($pagina - 1) * $filasPorPagina;

        $sql = "SELECT 
                    i.id_inventario, 
                    p.id_producto, 
                    p.nombre, 
                    i.categoria, 
                    i.cantidad, 
                    i.precio_unitario
                FROM inventario i
                JOIN productos p ON i.id_producto = p.id_producto
                WHERE p.nombre LIKE :busqueda
                ORDER BY i.id_inventario DESC
                LIMIT :offset, :limit";

        $stmt = $conn->prepare($sql);
        $stmt->bindValue(':busqueda', "%$busqueda%", PDO::PARAM_STR);
        $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
        $stmt->bindValue(':limit', $filasPorPagina, PDO::PARAM_INT);
        $stmt->execute();
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $sql_total = "SELECT COUNT(*)
                      FROM inventario i
                      JOIN productos p ON i.id_producto = p.id_producto
                      WHERE p.nombre LIKE :busqueda";

        $stmt_total = $conn->prepare($sql_total);
        $stmt_total->bindValue(':busqueda', "%$busqueda%", PDO::PARAM_STR);
        $stmt_total->execute();
        $total = $stmt_total->fetchColumn();

        echo json_encode(['success' => true, 'data' => $data, 'total' => $total]);
    }

    /* =======================================================
       ACCIÓN: LISTAR PRODUCTOS PARA SELECT
    ======================================================= */
    elseif ($accion === 'listar_productos') {

        $sql = "SELECT id_producto, nombre FROM productos ORDER BY nombre ASC";
        $stmt = $conn->query($sql);
        $data = $stmt->fetchAll(PDO::FETCH_ASSOC);

        echo json_encode(['success' => true, 'data' => $data]);
    }

    /* =======================================================
       ACCIÓN: INSERTAR PRODUCTO
    ======================================================= */
    elseif ($accion === 'insertar_producto') {

        $nombre = $_POST['nombre'] ?? '';
        $precio = floatval($_POST['precio'] ?? 0.00);
        $stock_inicial = intval($_POST['stock_inicial'] ?? 0);
        $categoria = $_POST['categoria'] ?? '';

        if (empty($nombre) || $precio <= 0 || empty($categoria)) {
            echo json_encode([
                'success' => false,
                'message' => 'Faltan datos obligatorios (Nombre, Precio > 0, Categoría).'
            ]);
            return;
        }

        // Insertar en productos
        $stmt = $conn->prepare(
            "INSERT INTO productos (nombre, precio, stock) VALUES (?, ?, ?)"
        );
        $stmt->execute([$nombre, $precio, $stock_inicial]);
        $id_producto_nuevo = $conn->lastInsertId();

        $mensaje = "Producto '$nombre' registrado con éxito. ";

        // Insertar en inventario si hay stock
        if ($stock_inicial > 0) {
            $stmt_inv = $conn->prepare(
                "INSERT INTO inventario (id_producto, categoria, cantidad, precio_unitario)
                 VALUES (?, ?, ?, ?)"
            );
            $stmt_inv->execute([
                $id_producto_nuevo,
                $categoria,
                $stock_inicial,
                $precio
            ]);

            $mensaje .= "Se registraron $stock_inicial unidades en Inventario.";
        } else {
            $mensaje .= "Inventario inicial establecido en 0.";
        }

        echo json_encode(['success' => true, 'message' => $mensaje]);
    }

    /* =======================================================
       ACCIÓN: EDITAR INVENTARIO
    ======================================================= */
    elseif ($accion === 'editar_inventario') {

        $id_inventario = $_POST['id_inventario'] ?? null;
        $nueva_categoria = $_POST['categoria'] ?? null;
        $nuevo_precio = floatval($_POST['precio_unitario'] ?? 0.0);

        if (!$id_inventario || empty($nueva_categoria) || $nuevo_precio <= 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos de edición inválidos o incompletos.'
            ]);
            return;
        }

        // Actualizar inventario
        $sql_update_inv =
            "UPDATE inventario SET categoria = ?, precio_unitario = ? WHERE id_inventario = ?";
        $stmt_inv = $conn->prepare($sql_update_inv);
        $stmt_inv->execute([$nueva_categoria, $nuevo_precio, $id_inventario]);

        // Obtener id_producto
        $stmt_prod_id = $conn->prepare("SELECT id_producto FROM inventario WHERE id_inventario = ?");
        $stmt_prod_id->execute([$id_inventario]);
        $id_producto = $stmt_prod_id->fetchColumn();

        // Actualizar precio en productos
        if ($id_producto) {
            $sql_update_prod = "UPDATE productos SET precio = ? WHERE id_producto = ?";
            $stmt_prod = $conn->prepare($sql_update_prod);
            $stmt_prod->execute([$nuevo_precio, $id_producto]);
        }

        echo json_encode(['success' => true, 'message' => 'Registro de inventario actualizado con éxito.']);
    }

    /* =======================================================
       ACCIÓN: MOVIMIENTO DE STOCK
    ======================================================= */
    elseif ($accion === 'movimiento') {

        $id_producto = $_POST['id_producto'] ?? null;
        $cantidad = intval($_POST['cantidad'] ?? 0);
        $tipo = $_POST['tipo'] ?? '';
        $categoria_nueva = $_POST['categoria'] ?? '';

        if (!$id_producto || $cantidad <= 0 || ($tipo !== 'entrada' && $tipo !== 'salida')) {
            echo json_encode([
                'success' => false,
                'message' => 'Datos de movimiento inválidos.'
            ]);
            return;
        }

        $operador = ($tipo === 'entrada') ? '+' : '-';

        // Verificar si existe inventario
        $stmt_check = $conn->prepare("SELECT COUNT(*) FROM inventario WHERE id_producto = ?");
        $stmt_check->execute([$id_producto]);
        $existe_inventario = $stmt_check->fetchColumn();

        /* --------------------------------------
           SI EXISTE INVENTARIO
        -------------------------------------- */
        if ($existe_inventario) {

            // Actualizar inventario
            $sql_update_inv =
                "UPDATE inventario SET cantidad = cantidad {$operador} ? WHERE id_producto = ?";
            $stmt_update_inv = $conn->prepare($sql_update_inv);
            $stmt_update_inv->execute([$cantidad, $id_producto]);

            // Actualizar productos
            $sql_update_prod =
                "UPDATE productos SET stock = stock {$operador} ? WHERE id_producto = ?";
            $stmt_update_prod = $conn->prepare($sql_update_prod);
            $stmt_update_prod->execute([$cantidad, $id_producto]);

            $mensaje = "Movimiento de {$tipo} ($cantidad) registrado con éxito.";

            // Verificar stock negativo
            if ($tipo === 'salida') {
                $stmt_check_qty = $conn->prepare(
                    "SELECT stock FROM productos WHERE id_producto = ?"
                );
                $stmt_check_qty->execute([$id_producto]);
                $cantidad_actual = $stmt_check_qty->fetchColumn();

                if ($cantidad_actual < 0) {

                    // Revertir inventario
                    $stmt_revert_inv = $conn->prepare(
                        "UPDATE inventario SET cantidad = cantidad + ? WHERE id_producto = ?"
                    );
                    $stmt_revert_inv->execute([$cantidad, $id_producto]);

                    // Revertir productos
                    $stmt_revert_prod = $conn->prepare(
                        "UPDATE productos SET stock = stock + ? WHERE id_producto = ?"
                    );
                    $stmt_revert_prod->execute([$cantidad, $id_producto]);

                    echo json_encode([
                        'success' => false,
                        'message' => 'Error de stock: Inventario insuficiente.'
                    ]);
                    return;
                }
            }
        }

        /* --------------------------------------
           SI NO EXISTE INVENTARIO (solo entradas)
        -------------------------------------- */
        else {

            if ($tipo === 'entrada') {

                if (empty($categoria_nueva)) {
                    echo json_encode([
                        'success' => false,
                        'message' => 'Debe seleccionar una Categoría para la primera entrada.'
                    ]);
                    return;
                }

                $precio_defecto = 0.00;

                $stmt_insert = $conn->prepare(
                    "INSERT INTO inventario 
                     (id_producto, categoria, cantidad, precio_unitario)
                     VALUES (?, ?, ?, ?)"
                );
                $stmt_insert->execute([
                    $id_producto,
                    $categoria_nueva,
                    $cantidad,
                    $precio_defecto
                ]);

                // Actualizar productos
                $sql_update_prod =
                    "UPDATE productos SET stock = stock + ? WHERE id_producto = ?";
                $stmt_update_prod = $conn->prepare($sql_update_prod);
                $stmt_update_prod->execute([$cantidad, $id_producto]);

                $mensaje = "El producto se ha añadido al inventario con entrada de ($cantidad).";
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'No se puede realizar salida. El producto no existe en inventario.'
                ]);
                return;
            }
        }

        echo json_encode(['success' => true, 'message' => $mensaje]);
    }

    /* =======================================================
       ACCIÓN: ELIMINAR REGISTRO
    ======================================================= */
    elseif ($accion === 'eliminar') {

        $id = $_POST['id_inventario'];

        $stmt_info = $conn->prepare(
            "SELECT id_producto, cantidad 
             FROM inventario 
             WHERE id_inventario = ?"
        );
        $stmt_info->execute([$id]);
        $info = $stmt_info->fetch(PDO::FETCH_ASSOC);

        if ($info) {

            // Revertir stock en productos
            $stmt_prod_update = $conn->prepare(
                "UPDATE productos SET stock = stock - ? WHERE id_producto = ?"
            );
            $stmt_prod_update->execute([
                $info['cantidad'],
                $info['id_producto']
            ]);

            // Eliminar inventario
            $stmt = $conn->prepare(
                "DELETE FROM inventario WHERE id_inventario = ?"
            );
            $stmt->execute([$id]);

            echo json_encode([
                'success' => true,
                'message' => 'Producto y su stock asociado eliminados del inventario.'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Registro de inventario no encontrado.'
            ]);
        }
    }

    /* =======================================================
       ACCIÓN NO RECONOCIDA
    ======================================================= */
    else {
        echo json_encode(['success' => false, 'message' => 'Acción no válida']);
    }

} catch (PDOException $e) {

    echo json_encode([
        'success' => false,
        'message' => 'Error de B.D.: ' . $e->getMessage()
    ]);
}

?>
